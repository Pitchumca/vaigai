var wms_layers = [];


        var lyr_GoogleMaps_0 = new ol.layer.Tile({
            'title': 'Google Maps',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'http://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'
            })
        });
var format_finalvaigaifromQGIStank_1 = new ol.format.GeoJSON();
var features_finalvaigaifromQGIStank_1 = format_finalvaigaifromQGIStank_1.readFeatures(json_finalvaigaifromQGIStank_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGIStank_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGIStank_1.addFeatures(features_finalvaigaifromQGIStank_1);
var lyr_finalvaigaifromQGIStank_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGIStank_1, 
                style: style_finalvaigaifromQGIStank_1,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGIStank_1.png" /> finalvaigaifromQGIS tank'
            });
var format_finalvaigaifromQGISbasinstream_2 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISbasinstream_2 = format_finalvaigaifromQGISbasinstream_2.readFeatures(json_finalvaigaifromQGISbasinstream_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISbasinstream_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISbasinstream_2.addFeatures(features_finalvaigaifromQGISbasinstream_2);
var lyr_finalvaigaifromQGISbasinstream_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISbasinstream_2, 
                style: style_finalvaigaifromQGISbasinstream_2,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISbasinstream_2.png" /> finalvaigaifromQGIS basinstream'
            });
var format_finalvaigaifromQGISVaigai_Villages_3 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISVaigai_Villages_3 = format_finalvaigaifromQGISVaigai_Villages_3.readFeatures(json_finalvaigaifromQGISVaigai_Villages_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISVaigai_Villages_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISVaigai_Villages_3.addFeatures(features_finalvaigaifromQGISVaigai_Villages_3);
var lyr_finalvaigaifromQGISVaigai_Villages_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISVaigai_Villages_3, 
                style: style_finalvaigaifromQGISVaigai_Villages_3,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISVaigai_Villages_3.png" /> finalvaigaifromQGIS Vaigai_Villages'
            });
var format_finalvaigaifromQGISVaigaiBasin2_4 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISVaigaiBasin2_4 = format_finalvaigaifromQGISVaigaiBasin2_4.readFeatures(json_finalvaigaifromQGISVaigaiBasin2_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISVaigaiBasin2_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISVaigaiBasin2_4.addFeatures(features_finalvaigaifromQGISVaigaiBasin2_4);
var lyr_finalvaigaifromQGISVaigaiBasin2_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISVaigaiBasin2_4, 
                style: style_finalvaigaifromQGISVaigaiBasin2_4,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISVaigaiBasin2_4.png" /> finalvaigaifromQGIS VaigaiBasin (#2)'
            });
var format_finalvaigaifromQGISTwaterbody_5 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISTwaterbody_5 = format_finalvaigaifromQGISTwaterbody_5.readFeatures(json_finalvaigaifromQGISTwaterbody_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISTwaterbody_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISTwaterbody_5.addFeatures(features_finalvaigaifromQGISTwaterbody_5);
var lyr_finalvaigaifromQGISTwaterbody_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISTwaterbody_5, 
                style: style_finalvaigaifromQGISTwaterbody_5,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISTwaterbody_5.png" /> finalvaigaifromQGIS Twaterbody'
            });
var format_finalvaigaifromQGISTanks2_6 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISTanks2_6 = format_finalvaigaifromQGISTanks2_6.readFeatures(json_finalvaigaifromQGISTanks2_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISTanks2_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISTanks2_6.addFeatures(features_finalvaigaifromQGISTanks2_6);
var lyr_finalvaigaifromQGISTanks2_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISTanks2_6, 
                style: style_finalvaigaifromQGISTanks2_6,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISTanks2_6.png" /> finalvaigaifromQGIS Tanks (#2)'
            });
var format_finalvaigaifromQGISStreams2_7 = new ol.format.GeoJSON();
var features_finalvaigaifromQGISStreams2_7 = format_finalvaigaifromQGISStreams2_7.readFeatures(json_finalvaigaifromQGISStreams2_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_finalvaigaifromQGISStreams2_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_finalvaigaifromQGISStreams2_7.addFeatures(features_finalvaigaifromQGISStreams2_7);
var lyr_finalvaigaifromQGISStreams2_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_finalvaigaifromQGISStreams2_7, 
                style: style_finalvaigaifromQGISStreams2_7,
                interactive: true,
                title: '<img src="styles/legend/finalvaigaifromQGISStreams2_7.png" /> finalvaigaifromQGIS Streams (#2)'
            });

lyr_GoogleMaps_0.setVisible(true);lyr_finalvaigaifromQGIStank_1.setVisible(true);lyr_finalvaigaifromQGISbasinstream_2.setVisible(true);lyr_finalvaigaifromQGISVaigai_Villages_3.setVisible(true);lyr_finalvaigaifromQGISVaigaiBasin2_4.setVisible(true);lyr_finalvaigaifromQGISTwaterbody_5.setVisible(true);lyr_finalvaigaifromQGISTanks2_6.setVisible(true);lyr_finalvaigaifromQGISStreams2_7.setVisible(true);
var layersList = [lyr_GoogleMaps_0,lyr_finalvaigaifromQGIStank_1,lyr_finalvaigaifromQGISbasinstream_2,lyr_finalvaigaifromQGISVaigai_Villages_3,lyr_finalvaigaifromQGISVaigaiBasin2_4,lyr_finalvaigaifromQGISTwaterbody_5,lyr_finalvaigaifromQGISTanks2_6,lyr_finalvaigaifromQGISStreams2_7];
lyr_finalvaigaifromQGIStank_1.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_finalvaigaifromQGISbasinstream_2.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_finalvaigaifromQGISVaigai_Villages_3.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_finalvaigaifromQGISVaigaiBasin2_4.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', 'snippet': 'snippet', });
lyr_finalvaigaifromQGISTwaterbody_5.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_finalvaigaifromQGISTanks2_6.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', 'snippet': 'snippet', });
lyr_finalvaigaifromQGISStreams2_7.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', 'snippet': 'snippet', });
lyr_finalvaigaifromQGIStank_1.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_finalvaigaifromQGISbasinstream_2.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_finalvaigaifromQGISVaigai_Villages_3.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_finalvaigaifromQGISVaigaiBasin2_4.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', 'snippet': '', });
lyr_finalvaigaifromQGISTwaterbody_5.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_finalvaigaifromQGISTanks2_6.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', 'snippet': '', });
lyr_finalvaigaifromQGISStreams2_7.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', 'snippet': '', });
lyr_finalvaigaifromQGIStank_1.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_finalvaigaifromQGISbasinstream_2.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_finalvaigaifromQGISVaigai_Villages_3.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_finalvaigaifromQGISVaigaiBasin2_4.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', 'snippet': 'no label', });
lyr_finalvaigaifromQGISTwaterbody_5.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_finalvaigaifromQGISTanks2_6.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', 'snippet': 'no label', });
lyr_finalvaigaifromQGISStreams2_7.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', 'snippet': 'no label', });
lyr_finalvaigaifromQGISStreams2_7.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});